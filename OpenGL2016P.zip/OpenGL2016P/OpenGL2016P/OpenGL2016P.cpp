// OpenGL2016P.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "GL/glew.h"
#include "GL/glut.h"
#include <math.h>
#include <windows.h>
#include "Matrix4D\Matrix4D.h"
#include "Mesh\MeshMathSurface.h"
#include <iostream>

float time;
MATRIX4D V;
bool bFordward, bBackward, bLeft, bRight, bUp, bDown, wireFrame;

VECTOR4D Tetraedro[]{ { 0,1,0,1 },{ 1,-1,0,1 },{ -1,-1,0,1 },{ 0,0,1,1 } };
int TetraedroIndices[]{ 0,1,2,0,2,3,2,1,3,0,3,1 };
VECTOR4D Colors[]{ { 1,0,0,1 },{ 0,1,0,1 },{ 0,0,1,1 },{ 1,1,1,1 } };

const float PI = 3.1416f;

float SinCos(float x, float y)
{
    return 0.3f * cos(x * PI * 1.5f) * sinf(y * PI * 1.5f);
}

float Plane(float x, float y)
{
    float A = 1.0f, B = 1.0f, C = 10.0f, D = 1.0f;
    return ((D * -1) - (A * x) - (B * y)) / C;
}

VECTOR4D Ellipsoid(float u, float v)
{
    float A = 1.0f, B = 1.0f, C = 1.0f;
    VECTOR4D vec{ A * cos(u) * cosf(v), B * cos(u) * sinf(v), C * sinf(u), 1 };
    return vec;
}

VECTOR4D Torus(float u, float v)
{
    float R = 1.0f, r = 0.5f;
    VECTOR4D vec{ (R + r * cos(u)) * cos(v), (R + r * cos(u)) * sinf(v), r * sinf(u), 1 };
    return vec;
}

CMeshMathSurface g_TheSurface;
CMeshMathSurface g_Plane;
CMeshMathSurface g_Ellipse;
CMeshMathSurface g_Torus;

void DisplayFunction()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glClearDepth(1.0f);
    int sx, sy;
    sx = glutGet(GLUT_WINDOW_WIDTH);
    sy = glutGet(GLUT_WINDOW_HEIGHT);
    MATRIX4D SAspect = Scaling(1.0f, static_cast<float>(sx) / static_cast<float>(sy), 1.0f);
    MATRIX4D SAspectEllipse = Scaling(1.0f, static_cast<float>(sx) / static_cast<float>(sy), 1.0f);
    MATRIX4D SAspectTorus = Scaling(1.0f, 0.3f, 0.3f);
    MATRIX4D SAspectPlane = Scaling(1.0f, static_cast<float>(sx) / static_cast<float>(sy), 1.0f);
    MATRIX4D R = RotationZ(time);
    MATRIX4D P = PerspectiveWidthHeightRH(0.5f, 0.5f, 1.0f, 10.0f);
    MATRIX4D M = SAspect * P * V * R * Translation(0.0f, 0.0f, -1.0f);
    MATRIX4D MEllipse = SAspectEllipse * P * V * R * Translation(0.0f, 0.0f, 0.0f);
    MATRIX4D MTorus = SAspectTorus * P * V * R;
    MATRIX4D MPlane = SAspectPlane * P * V * R * Translation(0.0f, 0.0f, 1.1f);
    glBegin(GL_TRIANGLES);
    /*for (int i = 0; i < sizeof(TetraedroIndices) / sizeof(int); i += 3)
    {
        for (int j = 0; j < 3; ++j)
        {
            auto &C = Colors[TetraedroIndices[i + j]];
            glColor4f(C.r, C.g, C.b, C.a);
            VECTOR4D V = M * Tetraedro[TetraedroIndices[i + j]];
            glVertex4f(V.x, V.y, V.z, V.w);
        }
    }*/
    g_TheSurface.Draw(M);
    g_Ellipse.Draw(MEllipse);
    g_Torus.Draw(MTorus);
    g_Plane.Draw(MPlane);
    glEnd();
    glutSwapBuffers();
}

void IdleFunction()
{
    time += 0.001f;
    MATRIX4D InvV = FastInverse(V);
    VECTOR4D XDir{ InvV.m00, InvV.m10, InvV.m20, 0 };
    VECTOR4D YDir{ InvV.m01, InvV.m11, InvV.m21, 0 };
    VECTOR4D ZDir{ InvV.m02, InvV.m12, InvV.m22, 0 };
    // Parte translativa de la camara
    VECTOR4D EyePos{ InvV.m03, InvV.m13, InvV.m23, 1 };
    VECTOR4D Speed{ 0.001f, 0.001f, 0.001f, 0 };
    if (bFordward)
        EyePos = EyePos - Speed * ZDir;
    if (bBackward)
        EyePos = EyePos + Speed * ZDir;
    if (bUp)
        EyePos = EyePos - Speed * YDir;
    if (bDown)
        EyePos = EyePos + Speed * YDir;
    if (bRight)
        EyePos = EyePos - Speed * XDir;
    if (bLeft)
        EyePos = EyePos + Speed * XDir;
    // Solo se cambio la posicion de la camara, por lo que se tiene que actualizar
    InvV.m03 = EyePos.x;
    InvV.m13 = EyePos.y;
    InvV.m23 = EyePos.z;
    V = FastInverse(InvV);
    // Produce que se repinte la pantalla
    glutPostRedisplay();
}

void OnKeyDown(unsigned char key, int x, int y)
{
    switch (key)
    {
    // Cuando se presione la tecla Esc se interrumpe la ejecucion del programa
    case 27:
        exit(0);
    case 'a':
        bFordward = true;
        break;
    case 'z':
        bBackward = true;
        break;
    default:
        break;
    }
}

void OnKeyUp(unsigned char key, int x, int y)
{
    switch (key)
    {
    case 'a':
        bFordward = false;
        break;
    case 'z':
        bBackward = false;
        break;
    case 'w':
        if (!wireFrame)
        {
            glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
            wireFrame = true;
        }
        else
        {
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
            wireFrame = false;
        }
        break;
    default:
        break;
    }
}

void OnSpecialDown(int key, int x, int y)
{
    switch (key)
    {
    case GLUT_KEY_DOWN:
        bDown = true;
        break;
    case GLUT_KEY_UP:
        bUp = true;
        break;
    case GLUT_KEY_LEFT:
        bLeft = true;
        break;
    case GLUT_KEY_RIGHT:
        bRight = true;
        break;
    default:
        break;
    }
}

void OnSpecialUp(int key, int x, int y)
{
    switch (key)
    {
    case GLUT_KEY_DOWN:
        bDown = false;
        break;
    case GLUT_KEY_UP:
        bUp = false;
        break;
    case GLUT_KEY_LEFT:
        bLeft = false;
        break;
    case GLUT_KEY_RIGHT:
        bRight = false;
        break;
    default:
        break;
    }
}

void OnMouse(int button, int state, int x, int y)
{
    // button:=(GLUT_LEFT_BUTTON|GLUT_MIDDLE_BUTTON|GLUT_RIGHT_BUTTON)
    // state:=(GLUT_DOWN|GLUT_UP)
}

int main(int argc, char* argv[])
{
    VECTOR4D a{ 0, 1, 0, 1 };
    VECTOR4D b{ 1, -1, 0, 1 };
    VECTOR4D c{ -1, -1, 0, 1 };

    VECTOR4D p1{ 0.0f, -1.1f, 0.0f, 1.0f };
    VECTOR4D p2{ 0.0f, -0.9f, 0.0f, 1.0f };

    cout << (PtInTriangle(a, b, c, p1) == true ? "Dentro" : "Fuera") << endl;   // Fuera
    cout << (PtInTriangle(a, b, c, p2) == true ? "Dentro" : "Fuera") << endl;   // Dentro
    cout << (PtInTriangle(a, b, c, a) == true ? "Dentro" : "Fuera") << endl;    // Fuera

    float w0, w1, w2;

    cout << (PtInTriangleBarycentric(a, b, c, p1, w0, w1, w2) == true ? "Dentro" : "Fuera") << endl;   // Fuera
    cout << (PtInTriangleBarycentric(a, b, c, p2, w0, w1, w2) == true ? "Dentro" : "Fuera") << endl;   // Dentro
    cout << (PtInTriangleBarycentric(a, b, c, a, w0, w1, w2) == true ? "Dentro" : "Fuera") << endl;    // Dentro

    // Inicializar la vista una sola vez al iniciar la ejecucion del programa
    VECTOR4D Target{ 0, 0, 0, 1 };
    VECTOR4D Eye{ 3, 3, 3, 1 };
    VECTOR4D Up{ 0, 0, 1, 0 };
    V = View(Eye, Target, Up);
    
    unsigned long steps = 15;
    VECTOR4D A{ 1, 0, 0, 1 }, B{ 0, 1, 0, 1 }, C{ 0, 0, 1, 1 }, D{ 1, 1, 1, 1 };

    // Generacion de una malla por medio de una funcion analitica
    g_TheSurface.BuildAnalyticSurface(steps, steps, -1, -1, 2.0f / (steps - 1), 2.0f / (steps - 1), SinCos);
    // Aplicacion de colores a la malla generada
    g_TheSurface.SetColor(A, B, C, D);
    g_Plane.BuildAnalyticSurface(steps, steps, -1, -1, 1.0f / (steps - 1), 1.0f / (steps - 1), Plane);
    g_Plane.SetColor(A, B, C, D);
    // Generacion de una malla para una elipse/esfera
    g_Ellipse.BuildParametricSurface(steps, steps, -PI / 2, -PI, (2 * PI) / (steps - 1), PI / (steps -1), Ellipsoid);
    g_Ellipse.SetColor(A, B, C, D);
    // Generacion de una malla para un toroide
    g_Torus.BuildParametricSurface(steps, steps, 0, 0, (2 * PI) / (steps - 1), (2 * PI) / (steps - 1), Torus);
    g_Torus.SetColor(A, B, C, D);
    // glutinit inicializa la biblioteca de glut
    glutInit(&argc, argv);
    // propiedades de la ventana
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
    // Tama�o de la ventana
    glutInitWindowSize(400, 400);
    // Posicion inicial en donde aparece la ventana
    glutInitWindowPosition(100, 100);
    // Crear la ventana de OpenGL
    glutCreateWindow("Mi primer programa en OpenGL");
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LESS);
    glDepthRange(0, 1);
    // Callback que se llamara cada que se ejecuta una iteracion en el ciclo principal
    glutDisplayFunc(DisplayFunction);
    // Callback para la funcion que se ejecutara cuando este en reposo (idle)
    glutIdleFunc(IdleFunction);
    glutKeyboardFunc(OnKeyDown);
    glutKeyboardUpFunc(OnKeyUp);
    glutSpecialFunc(OnSpecialDown);
    glutSpecialUpFunc(OnSpecialUp);
    glutMouseFunc(OnMouse);
    // Ciclo principal
    glutMainLoop();

    return 0;
}
