#include "../stdafx.h"
#include "Mesh.h"
#include "GL/glew.h"

CMesh::CMesh()
{
}

CMesh::~CMesh()
{
}

void CMesh::Draw(const MATRIX4D &M)
{
    for (unsigned int i = 0; i < m_Indexes.size(); i += 3)
    {
        for (int j = 0; j < 3; ++j)
        {
            auto &C = m_Vertexes[m_Indexes[i + j]].Color;
            glColor4f(C.r, C.g, C.b, C.a);
            VECTOR4D V = M * m_Vertexes[m_Indexes[i + j]].Position;
            glVertex4f(V.x, V.y, V.z, V.w);
        }
    }
}
