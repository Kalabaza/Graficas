#pragma once

#include "..\Matrix4D\Matrix4D.h"
#include <vector>

using namespace std;

class CMesh
{
public:
    struct VERTEX
    {
        VECTOR4D Position;
        VECTOR4D Color;
    };
    // Arreglo de vertices
    vector<VERTEX> m_Vertexes;
    // Buffer de indices
    vector<unsigned int> m_Indexes;
    
    CMesh();
    ~CMesh();

    // Metodo para dibujar la maya en pantalla
    void Draw(const MATRIX4D &M);
};
